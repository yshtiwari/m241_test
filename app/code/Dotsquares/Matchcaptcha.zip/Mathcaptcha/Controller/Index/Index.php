<?php
namespace Dotsquares\Mathcaptcha\Controller\Index;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
 
class Index extends \Magento\Framework\App\Action\Action
{
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    )
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }
 
    public function execute()
    {
       
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$customerSession = $objectManager->create('Magento\Customer\Model\Session');
		$sessionVal=$customerSession->getMyValue();
		if($this->getRequest()->isPost() && ($this->getRequest()->getPost('captch')!=$sessionVal) ){
			$this->messageManager->addError(
			$this->_objectManager->get('Magento\Framework\Escaper')->escapeHtml("Bitte überprüfen Sie Ihre Eingabe"));
		}else{
		
		if($this->getRequest()->getPost('submit') !== null && $this->getRequest()->getPost('submit')=="Submit" && $this->getRequest()->getPost('entityid')){
				
			// if($_POST['entityid']=="" || $_POST['pincode']){	
				// $arrayquestion=array("status"=>0,"message"=>"Please fill required field !");
				// echo $_GET['callback'] . '(';
				// print_r(json_encode($arrayquestion));
				// echo ')';
				// die();
			// }
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
			$resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
			$connection = $resource->getConnection();
			$tableName = $resource->getTableName('customer_address_entity'); //gives table name with prefix
			 
			//Select Data from table
			$sql ="SELECT cae.parent_id as id FROM customer_address_entity as cae inner join customer_entity_varchar as cev on cev.entity_id=cae.parent_id where cev.value='".$this->getRequest()->getPost('entityid')."' and cae.postcode='".$this->getRequest()->getPost('pincode')."'";
			$result = $connection->fetchAll($sql); // gives associated array, table fields as key in array.

			if(count($result) > 0){


			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$customer = $objectManager->create('Magento\Customer\Model\Customer')->load($result[0]['id']); //2 is Customer ID
			$customerSession = $objectManager->create('Magento\Customer\Model\Session');
			$customerSession->setCustomerAsLoggedIn($customer);
			if($customerSession->isLoggedIn()) {
				// $arrayquestion=array("status"=>1,"message"=>"successfull login");
				// echo $_GET['callback'] . '(';
				// print_r(json_encode($arrayquestion));
				// echo ')';
				$this->messageManager->addSuccess(
				   $this->_objectManager->get('Magento\Framework\Escaper')->escapeHtml("Erfolgreich angemeldet. Bitte überprüfen Sie Kontoinformationen (E-Mailadresse und Passwort).")
				);
				$this->_redirect('customer/account/');
				return;
			}
			}else{
				// $arrayquestion=array("status"=>0,"message"=>"Bitte überprüfen Sie Ihre Eingabe");
				// echo $_GET['callback'] . '(';
				// print_r(json_encode($arrayquestion));
				// echo ')';
				$this->messageManager->addError(
			   $this->_objectManager->get('Magento\Framework\Escaper')->escapeHtml("Bitte überprüfen Sie Ihre Eingabe")
			);
			}
			//die();			
		}elseif($this->getRequest()->getPost('submit') !== null  && $this->getRequest()->getPost('submit') == "Submit"){
		$this->messageManager->addError(
			   $this->_objectManager->get('Magento\Framework\Escaper')->escapeHtml("Bitte überprüfen Sie Ihre Eingabe")
			);
		}
		} 
		 $resultPageFactory = $this->resultPageFactory->create();
        // Add page title
       /* $resultPageFactory->getConfig()->getTitle()->set(__('Example module'));
 
        // Add breadcrumb
        // @var \Magento\Theme\Block\Html\Breadcrumbs 
        $breadcrumbs = $resultPageFactory->getLayout()->getBlock('breadcrumbs');
        $breadcrumbs->addCrumb('home',
            [
                'label' => __('Home'),
                'title' => __('Home'),
                'link' => $this->_url->getUrl('')
            ]
        );
        $breadcrumbs->addCrumb('tutorial_example',
            [
                'label' => __('Example'),
                'title' => __('Example')
            ]
        );
		*/
        return $resultPageFactory;
    }
}
 