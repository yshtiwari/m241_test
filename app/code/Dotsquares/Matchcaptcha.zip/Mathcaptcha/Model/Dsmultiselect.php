<?php

namespace Dotsquares\Mathcaptcha\Model;
use Magento\Framework\Data\OptionSourceInterface;
use Magento\Framework\Option\ArrayInterface; 
class Dsmultiselect implements OptionSourceInterface
{
    
	public function toOptionArray()
	{
		$arr = $this->toArray();
		$ret = [];
		foreach ($arr as $key => $value) {
			$ret[] = [
				'value' => $key,
				'label' => $value
			];
		}
		return $ret;
	}

	/*
	 * Get options in "key-value" format
	 * @return array
	 */
	public function toArray()
	{
		$choose = [
			'+' => 'addition(+)',
			'-' => 'subtraction(-)',
			'*' => 'multiplication(*)',
			'/' => 'division(/)'
			
		];
		return $choose;
	}
}