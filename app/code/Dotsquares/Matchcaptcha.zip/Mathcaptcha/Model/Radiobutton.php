<?php

namespace Dotsquares\Mathcaptcha\Model;
use Magento\Framework\Data\OptionSourceInterface;
use Magento\Framework\Option\ArrayInterface; 
class Radiobutton implements OptionSourceInterface
{
 
public function toOptionArray()
    {
        return [['value' => 'numbers', 'label' => __('Numbers')], ['value' => 'words', 'label' => __('Words')],];
    }
}