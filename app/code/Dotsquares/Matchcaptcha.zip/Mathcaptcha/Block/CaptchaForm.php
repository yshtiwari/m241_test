<?php

namespace Dotsquares\Mathcaptcha\Block;

class CaptchaForm extends \Magento\Framework\View\Element\Template {

    public function __construct(\Magento\Framework\View\Element\Template\Context $context //
    ) {
        parent::__construct($context);
    }

    public function _prepareLayout() {
        return parent::_prepareLayout();
    }

}
